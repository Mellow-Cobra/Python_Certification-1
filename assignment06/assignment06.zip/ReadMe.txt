----------------------------------+------------------------------------+
| Select                           | Description                        |
+==================================+====================================+
| Amend Employee Data in data file | Amend                              |
+----------------------------------+------------------------------------+
| Add                              | Add new Employee Data to data file |
+----------------------------------+------------------------------------+
| View                             | View all entries in CSV file       |
+----------------------------------+------------------------------------+
| View Current Employees           | Current                            |
+----------------------------------+------------------------------------+
| CSV                              | Make CSV file                      |
+----------------------------------+------------------------------------+
| Schedule for Review              | Review                             |
+----------------------------------+------------------------------------+
| View Former Employees            | Former                             |
+----------------------------------+------------------------------------+
| Exit                             | Exit this application              |
+----------------------------------+-------------------------------------

Use python Assignment_6.py to run!


Add - Add new Employee Data to data file 

View - View all entries in CSV file

Amend - Amend Employee Data in data file

Review - Schedule for review

Former - View Former Employees

Exit - Exit this application

CSV - Create new CSV file and over asserts the original read in hence you have add data to this one via program

Current - View all current employees
